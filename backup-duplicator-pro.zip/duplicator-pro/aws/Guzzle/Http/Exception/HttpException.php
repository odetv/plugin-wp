<?php
namespace DuplicatorPro\Guzzle\Http\Exception;

defined("ABSPATH") or die("");

use DuplicatorPro\Guzzle\Common\Exception\GuzzleException;

/**
 * Http exception interface
 */
interface HttpException extends GuzzleException {}
